/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class RegistrationHR {
   
    public static void main(String[] args)
            throws Exception
    {HRRegistration f = new HRRegistration();
}
}